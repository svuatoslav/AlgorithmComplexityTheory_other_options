﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int Q = 4;
            char[] Alphabet = { '0', '1' };
            const string DeltaPath = "C:\\...\\ConsoleApp1\\bin\\Debug\\Delta.xlsx";
            const int StartState = 0;
            int[] EndStates = new int[] { 3 };
            _ = new _3(Q, Alphabet, DeltaPath, StartState, EndStates);

            _ = new _6();
        }
    }
}
