﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valentina6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            _6cs _ = new _6cs();
        }
    }
}
