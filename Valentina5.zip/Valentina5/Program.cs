﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valentina5
{
    internal class Program
    {
        static void Main()
        {
            _5 _5 = new _5();
            Console.ReadKey();
        }
    }
}
